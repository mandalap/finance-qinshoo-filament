<?php

namespace App\Filament\Resources\KategoriTransaksis\Pages;

use App\Filament\Resources\KategoriTransaksis\KategoriTransaksiResource;
use Filament\Resources\Pages\CreateRecord;

class CreateKategoriTransaksi extends CreateRecord
{
    protected static string $resource = KategoriTransaksiResource::class;
}
