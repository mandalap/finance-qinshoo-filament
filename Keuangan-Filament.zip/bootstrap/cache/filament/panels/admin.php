<?php return array (
  'livewireComponents' => 
  array (
    'App\\Filament\\Resources\\ActivityLogs\\Pages\\ListActivityLogs' => 'App\\Filament\\Resources\\ActivityLogs\\Pages\\ListActivityLogs',
    'App\\Filament\\Resources\\ActivityLogs\\Pages\\ViewActivityLog' => 'App\\Filament\\Resources\\ActivityLogs\\Pages\\ViewActivityLog',
    'App\\Filament\\Resources\\Budgets\\Pages\\CreateBudget' => 'App\\Filament\\Resources\\Budgets\\Pages\\CreateBudget',
    'App\\Filament\\Resources\\Budgets\\Pages\\EditBudget' => 'App\\Filament\\Resources\\Budgets\\Pages\\EditBudget',
    'App\\Filament\\Resources\\Budgets\\Pages\\ListBudgets' => 'App\\Filament\\Resources\\Budgets\\Pages\\ListBudgets',
    'App\\Filament\\Resources\\Budgets\\Pages\\ViewBudget' => 'App\\Filament\\Resources\\Budgets\\Pages\\ViewBudget',
    'App\\Filament\\Resources\\KategoriTransaksis\\Pages\\CreateKategoriTransaksi' => 'App\\Filament\\Resources\\KategoriTransaksis\\Pages\\CreateKategoriTransaksi',
    'App\\Filament\\Resources\\KategoriTransaksis\\Pages\\EditKategoriTransaksi' => 'App\\Filament\\Resources\\KategoriTransaksis\\Pages\\EditKategoriTransaksi',
    'App\\Filament\\Resources\\KategoriTransaksis\\Pages\\ListKategoriTransaksis' => 'App\\Filament\\Resources\\KategoriTransaksis\\Pages\\ListKategoriTransaksis',
    'App\\Filament\\Resources\\PengajuanBarangs\\Pages\\CreatePengajuanBarang' => 'App\\Filament\\Resources\\PengajuanBarangs\\Pages\\CreatePengajuanBarang',
    'App\\Filament\\Resources\\PengajuanBarangs\\Pages\\EditPengajuanBarang' => 'App\\Filament\\Resources\\PengajuanBarangs\\Pages\\EditPengajuanBarang',
    'App\\Filament\\Resources\\PengajuanBarangs\\Pages\\ListPengajuanBarangs' => 'App\\Filament\\Resources\\PengajuanBarangs\\Pages\\ListPengajuanBarangs',
    'App\\Filament\\Resources\\PengajuanBarangs\\Pages\\ViewPengajuanBarang' => 'App\\Filament\\Resources\\PengajuanBarangs\\Pages\\ViewPengajuanBarang',
    'App\\Filament\\Resources\\PengajuanBarangs\\RelationManagers\\DetailBarangRelationManager' => 'App\\Filament\\Resources\\PengajuanBarangs\\RelationManagers\\DetailBarangRelationManager',
    'App\\Filament\\Resources\\TransaksiKeuangans\\Pages\\CreateTransaksiKeuangan' => 'App\\Filament\\Resources\\TransaksiKeuangans\\Pages\\CreateTransaksiKeuangan',
    'App\\Filament\\Resources\\TransaksiKeuangans\\Pages\\EditTransaksiKeuangan' => 'App\\Filament\\Resources\\TransaksiKeuangans\\Pages\\EditTransaksiKeuangan',
    'App\\Filament\\Resources\\TransaksiKeuangans\\Pages\\ListTransaksiKeuangans' => 'App\\Filament\\Resources\\TransaksiKeuangans\\Pages\\ListTransaksiKeuangans',
    'App\\Filament\\Resources\\TransaksiKeuangans\\Pages\\ViewTransaksiKeuangan' => 'App\\Filament\\Resources\\TransaksiKeuangans\\Pages\\ViewTransaksiKeuangan',
    'App\\Filament\\Resources\\Users\\Pages\\CreateUser' => 'App\\Filament\\Resources\\Users\\Pages\\CreateUser',
    'App\\Filament\\Resources\\Users\\Pages\\EditUser' => 'App\\Filament\\Resources\\Users\\Pages\\EditUser',
    'App\\Filament\\Resources\\Users\\Pages\\ListUsers' => 'App\\Filament\\Resources\\Users\\Pages\\ListUsers',
    'App\\Filament\\Resources\\Users\\Pages\\ViewUser' => 'App\\Filament\\Resources\\Users\\Pages\\ViewUser',
    'App\\Filament\\Pages\\DashboardPage' => 'App\\Filament\\Pages\\DashboardPage',
    'App\\Filament\\Pages\\EditProfile' => 'App\\Filament\\Pages\\EditProfile',
    'Filament\\Livewire\\DatabaseNotifications' => 'Filament\\Livewire\\DatabaseNotifications',
    'Filament\\Auth\\Pages\\EditProfile' => 'Filament\\Auth\\Pages\\EditProfile',
    'Filament\\Livewire\\GlobalSearch' => 'Filament\\Livewire\\GlobalSearch',
    'Filament\\Livewire\\Notifications' => 'Filament\\Livewire\\Notifications',
    'Filament\\Livewire\\Sidebar' => 'Filament\\Livewire\\Sidebar',
    'Filament\\Livewire\\SimpleUserMenu' => 'Filament\\Livewire\\SimpleUserMenu',
    'Filament\\Livewire\\Topbar' => 'Filament\\Livewire\\Topbar',
    'Filament\\Auth\\Pages\\Login' => 'Filament\\Auth\\Pages\\Login',
  ),
  'clusters' => 
  array (
  ),
  'clusteredComponents' => 
  array (
  ),
  'clusterDirectories' => 
  array (
  ),
  'clusterNamespaces' => 
  array (
  ),
  'pages' => 
  array (
    'E:\\development\\Keuangan-Filament\\app\\Filament\\Pages\\DashboardPage.php' => 'App\\Filament\\Pages\\DashboardPage',
    'E:\\development\\Keuangan-Filament\\app\\Filament\\Pages\\EditProfile.php' => 'App\\Filament\\Pages\\EditProfile',
    0 => 'App\\Filament\\Pages\\DashboardPage',
  ),
  'pageDirectories' => 
  array (
    0 => 'E:\\development\\Keuangan-Filament\\app\\Filament/Pages',
  ),
  'pageNamespaces' => 
  array (
    0 => 'App\\Filament\\Pages',
  ),
  'resources' => 
  array (
    'E:\\development\\Keuangan-Filament\\app\\Filament\\Resources\\ActivityLogs\\ActivityLogResource.php' => 'App\\Filament\\Resources\\ActivityLogs\\ActivityLogResource',
    'E:\\development\\Keuangan-Filament\\app\\Filament\\Resources\\Budgets\\BudgetResource.php' => 'App\\Filament\\Resources\\Budgets\\BudgetResource',
    'E:\\development\\Keuangan-Filament\\app\\Filament\\Resources\\KategoriTransaksis\\KategoriTransaksiResource.php' => 'App\\Filament\\Resources\\KategoriTransaksis\\KategoriTransaksiResource',
    'E:\\development\\Keuangan-Filament\\app\\Filament\\Resources\\PengajuanBarangs\\PengajuanBarangResource.php' => 'App\\Filament\\Resources\\PengajuanBarangs\\PengajuanBarangResource',
    'E:\\development\\Keuangan-Filament\\app\\Filament\\Resources\\TransaksiKeuangans\\TransaksiKeuanganResource.php' => 'App\\Filament\\Resources\\TransaksiKeuangans\\TransaksiKeuanganResource',
    'E:\\development\\Keuangan-Filament\\app\\Filament\\Resources\\Users\\UserResource.php' => 'App\\Filament\\Resources\\Users\\UserResource',
  ),
  'resourceDirectories' => 
  array (
    0 => 'E:\\development\\Keuangan-Filament\\app\\Filament/Resources',
  ),
  'resourceNamespaces' => 
  array (
    0 => 'App\\Filament\\Resources',
  ),
  'widgets' => 
  array (
  ),
  'widgetDirectories' => 
  array (
  ),
  'widgetNamespaces' => 
  array (
  ),
);