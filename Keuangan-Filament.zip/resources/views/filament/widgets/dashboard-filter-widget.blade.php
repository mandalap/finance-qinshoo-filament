<x-filament-widgets::widget>
    <x-filament::section>
        <x-slot name="heading">
            Filter Dashboard
        </x-slot>
        
        <x-slot name="description">
            Pilih periode untuk melihat data keuangan
        </x-slot>

        {{ $this->form }}
    </x-filament::section>
</x-filament-widgets::widget>
